How to start the ClyveTV:
It's my first time using this software: Click OOBE_Page1.html
I am going back to using this software: Click ClyveFinder.html